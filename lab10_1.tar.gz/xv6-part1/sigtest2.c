#include "types.h"
#include "stat.h"
#include "user.h"

void signal_handler1(int sig_type)
{
  printf(1, "Signal1 handler invoked of [%d] !!!. signal type: %d \n", getpid(),sig_type);

  if(sig_type == 1)
    exit();
  else
    signal_ret();  
}

void signal_handler2(int sig_type)
{
  printf(1, "Signal2 handler invoked of [%d] !!!. signal type: %d \n", getpid(),sig_type);

  if(sig_type == 1)
    exit();
  else
    signal_ret();  
}

int
main(int argc, char *argv[])
{
  int pid1;
  int pid2;

  pid1 = fork();
  if(pid1 == 0)
  {
    signal((char *)signal_handler1);
    printf(1, "\n[%d] Process will be registered to handler 1\n",getpid());
    
    while(1);
    exit();
  }


  
  pid2 = fork();
  if(pid2 == 0)
  {
    signal((char *)signal_handler2);
    sleep(3*100);
    printf(1, "\n[%d] Process will be registered to handler 2\n", getpid());
    
    while(1);
    exit();
  }

  sleep(6 * 100);
  printf(1, "\n[%d] Parent sends signal '2' to child [%d] \n", getpid(),pid1);
  signal_send(pid1, 2);

  sleep(3 * 100);
  printf(1, "\n[%d] Parent sends signal '3' to child [%d] \n", getpid(),pid2);
  signal_send(pid2, 3);



  sleep(3 * 100);
  printf(1, "\n[%d] Parent sends signal '11' to child [%d] \n", getpid(),pid2);
  signal_send(pid2, 11);

  sleep(3 * 100);
  printf(1, "\n[%d] Parent sends signal '16' to child [%d] \n", getpid(),pid1);
  signal_send(pid1, 16);



  sleep(3 * 100);
  printf(1, "\n[%d] Parent sends signal '52' to child [%d] \n", getpid(),pid2);
  signal_send(pid2, 52);

  sleep(3 * 100);
  printf(1, "\n[%d] Parent sends signal '36' to child [%d] \n", getpid(),pid2);
  signal_send(pid2, 36);

  
  wait();  
  wait();
  exit();
}
