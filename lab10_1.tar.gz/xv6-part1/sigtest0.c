#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  int pid;

  pid = fork();
  if(pid == 0)
  {
    while(1)
    {
      sleep(100);
    }
    exit();
  }

  printf(1, "\n[%d] Parent forked a child [%d] \n", getpid(),pid);

  sleep(5 * 100);
  printf(1, "\n[%d] Parent sends signal '5' to child \n", getpid());
  signal_send(pid, 5);

  sleep(5 * 100);
  printf(1, "\n[%d] Parent sends signal '6' to child \n", getpid());
  signal_send(pid, 6);

  sleep(5 * 100);
  printf(1, "\n[%d] Parent sends signal '1' to child \n", getpid());
  signal_send(pid, 1);

  wait();  
  printf(1, "[%d] Child process has terminated \n", getpid());
  exit();
}
